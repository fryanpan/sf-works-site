import type { MountFn, StateHook } from './mdx-component-runtime.js';
export interface SnapshotOptions {
    /** The component's id, which a refusal names. */
    id?: string;
    /** The clock the rate limit reads; a test hands in its own. */
    now?: () => number;
}
/** A hook over a copy of `snapshot`. A snapshot that is not an object is
 *  read as an empty state. */
export declare function snapshotState(snapshot: unknown, opts?: SnapshotOptions): StateHook;
/** Mount `mount` into `el` with `props` and, when there is a snapshot, a
 *  hook over it. Returns the component's cleanup, or one that does nothing. */
export declare function mountFromSnapshot(el: HTMLElement, mount: MountFn, props: Record<string, unknown>, snapshot?: unknown, opts?: SnapshotOptions): () => void;

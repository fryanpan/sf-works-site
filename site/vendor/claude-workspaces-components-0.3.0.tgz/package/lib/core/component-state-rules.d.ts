/**
 * The rules a component state write is held to, on every host: the live hook
 * over a doc's Y.Doc (`mdx-component-state.ts`) and the hook over a JSON
 * snapshot on a page that is not a doc (`component-snapshot.ts`). One copy,
 * so a component a site accepts is one a doc accepts, and the reverse: the
 * same paths, the same JSON-only values, no `__proto__` key, the same depth,
 * size and rate limits. The doc-wide size limit is the live hook's alone,
 * since a snapshot holds one component.
 *
 * Plain functions over plain JSON; it imports nothing, so a site bundling the
 * snapshot hook gets no Yjs.
 */
import type { StatePath } from './mdx-component-runtime.js';
export declare const STATE_LIMITS: {
    readonly instanceBytes: number;
    readonly docBytes: number;
    readonly depth: 8;
    readonly writesPerSecond: 20;
};
export declare function segments(path: StatePath): string[];
export declare const kb: (bytes: number) => number;
export declare function byteLength(value: unknown): number;
export declare function depthOf(value: unknown): number;
/** Why `value` is not JSON, or null when it is. */
export declare function notJson(value: unknown, where: string): string | null;
type Container = Record<string, unknown> | unknown[];
export declare const isContainer: (v: unknown) => v is Container;
export declare function indexIn(arr: {
    length: number;
}, seg: string, path: string, extend: boolean): number;
/** The state `op` would leave, worked on a plain copy so a refusal changes
 *  nothing. Throws a message for a path that cannot be followed. */
export declare function applyPlain(state: Record<string, unknown>, segs: string[], op: PlainOp): unknown;
export type PlainOp = {
    kind: 'set';
    value: unknown;
} | {
    kind: 'push';
    value: unknown;
} | {
    kind: 'delete';
};
/** Why `op` at `segs` is refused before it is tried, or null. */
export declare function opRefusal(segs: string[], op: PlainOp): string | null;
/** Why `next` as component `id`'s state is past the depth or the
 *  one-component size limit, or null. */
export declare function componentSizeRefusal(id: string, next: unknown): string | null;
/**
 * Check one write against `state` (plain JSON, which is not changed) and
 * work out the state it would leave. A refusal says why. The snapshot hook's
 * whole check; the live hook adds the doc-wide limit.
 */
export declare function checkWrite(state: Record<string, unknown>, path: StatePath, op: PlainOp, id: string): {
    next: unknown;
} | {
    error: string;
};
/** The accepted write times still inside the last second at `t`. */
export declare function recentWrites(times: readonly number[], t: number): number[];
/** Why one more write now is too fast, given the second's accepted writes. */
export declare function rateRefusal(recent: readonly number[], id: string): string | null;
export {};

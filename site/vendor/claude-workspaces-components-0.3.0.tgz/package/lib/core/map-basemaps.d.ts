/**
 * The street maps a `<StreetMap>` may draw under its data, and the one seam a
 * different provider plugs into.
 *
 * A doc names a basemap by key (`basemap="carto-light"`), never by URL, so the
 * origins a map loads tiles from are the ones listed here and nowhere else
 * (components design, decision 7: network origins come from a list the owner
 * controls, not from a doc). Adding a provider is one entry. A provider that
 * needs a key names it in `key`; the key itself is never written here or in a
 * doc. The server holds it and hands it only to a page whose doc draws a map
 * on that basemap (`routes/doc-map-key.ts`); with no key set, the map draws
 * on `fallback`, and says so when the doc named the keyed basemap itself.
 *
 * Terms, read 13 Nov 2026:
 *  - `osm`: the OpenStreetMap Foundation's standard tiles. Free and keyless,
 *    attribution required, no bulk prefetch, and "heavy use" is not allowed
 *    (https://operations.osmfoundation.org/policies/tiles/). A board's doc
 *    readers are a handful of people, which is light use.
 *  - `carto-light`: CARTO's Positron raster tiles over OpenStreetMap data.
 *    Keyless; attribution to OpenStreetMap and CARTO required; free for
 *    non-commercial use up to 75,000 map views a month
 *    (https://github.com/CartoDB/basemap-styles#1-web-raster-basemaps).
 *  - `google`: Google's roadmap, drawn by the Maps JavaScript API under a
 *    browser key restricted to the board's site, and moved under Leaflet's
 *    layers by GoogleMutant (`map-entry.ts`). The API puts Google's logo and
 *    terms link on the map itself, as the terms require; billed per map load
 *    (https://cloud.google.com/maps-platform/terms).
 */
export interface Basemap {
    /** Shown in the source and in errors. */
    label: string;
    /** An XYZ tile template: `{z}/{x}/{y}`, and `{s}` for a subdomain. Empty
     *  for a provider whose own script draws the map (`script`). */
    tiles: string;
    /** The provider's map script, for one drawn by its own API rather than
     *  from XYZ tiles. The page adds the key the server handed it. */
    script?: string;
    subdomains?: string;
    /** The credit the provider's terms require, drawn in the map's corner.
     *  Leaflet writes it as HTML, which is why only this file supplies it. */
    attribution: string;
    maxZoom: number;
    /** Every origin the map's requests go to. `https://*.example.com` stands
     *  for any subdomain of it (`basemapAllows`). */
    origins: string[];
    /** The environment variable the server reads the provider's key from. */
    key?: string;
    /** The basemap drawn instead when the server holds no key. */
    fallback?: string;
    /** Where the provider's terms are. */
    terms: string;
}
export declare const BASEMAPS: Readonly<Record<string, Basemap>>;
/** The basemap a tag with no `basemap` prop draws on: Google, the owner's
 *  choice, on a server that holds its key, and its `fallback` (OpenStreetMap)
 *  without a word on one that does not. */
export declare const DEFAULT_BASEMAP = "google";
export declare function basemapOf(name: string): Basemap | undefined;
/** Whether `url` goes to one of the origins `base` lists. */
export declare function basemapAllows(base: Basemap, url: string): boolean;

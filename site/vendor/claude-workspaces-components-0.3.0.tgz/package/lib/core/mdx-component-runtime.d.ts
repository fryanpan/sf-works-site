/**
 * The JSX runtime every component bundle carries (`cw/jsx-runtime`), and the
 * `render` its entry calls on the doc page.
 *
 * A component is a plain ES module (design decision 10):
 *
 *   export default function mount(el, props, state?) { … return cleanup? }
 *
 * so one file runs in a doc, on an Astro page and on SF Works with no
 * framework. JSX, in the doc's tag and in a component's own `.tsx`, compiles
 * to `jsx()` calls that build DOM at once: `<b>{name}</b>` is an element a
 * component can `append`. A string tag (`<div>`, `<wa-carousel>`) is made with
 * `document.createElement`. A function tag gets a `<div class="mdx-component">`
 * of its own and is called with its props, its children already built as DOM
 * nodes in `props.children`, so a carousel can put each child in a slide. A
 * built-in (`<PlotChart>`) is drawn by the page through `api.builtins`.
 *
 * A function tag with an `id` prop gets that id's live state as its third
 * argument, from `api.state` (`core/mdx-component-state.ts`); two tags with
 * one id share one state. A tag without an id, or a host with no state (an
 * Astro page), gets `undefined`, so a component works without state.
 *
 * Text only ever reaches the DOM as a text node. Nothing here sets
 * `innerHTML` or evaluates a string.
 */
export declare const Fragment: unique symbol;
/** A tag the page draws itself. */
export interface CwBuiltin {
    readonly $$builtin: string;
}
/** A path into a component's state: `"pins.a.x"` or `["pins", "a", "x"]`.
 *  A list item is named by its index. */
export type StatePath = string | readonly (string | number)[];
/** What a write returns. A refused write changed nothing and says why. */
export type StateWrite = {
    ok: true;
} | {
    ok: false;
    error: string;
};
/** A component's live state, shared by every page holding the doc. */
export interface StateHook {
    /** The value at `path`, or the whole state; plain JSON, a copy. */
    get(path?: StatePath): unknown;
    set(path: StatePath, value: unknown): StateWrite;
    /** Append to the list at `path`, making the list if there is none. */
    push(path: StatePath, value: unknown): StateWrite;
    delete(path: StatePath): StateWrite;
    /** Called with the whole state after any change, from this page or
     *  another. Returns the unsubscribe. */
    on(fn: (state: unknown) => void): () => void;
    /** False on a page that may read and may not write. */
    readonly canWrite: boolean;
}
/** A component's default export. It may return a cleanup; one that returns
 *  nothing is typed `void`, which is why the union names it. */
export type MountFn = (el: HTMLElement, props: Record<string, unknown>, state?: StateHook) => (() => void) | void;
/** What the page hands a bundle's entry. */
export interface ComponentHostApi {
    builtins: Record<string, (el: HTMLElement, props: Record<string, unknown>) => void>;
    /** The live state for a tag's `id`, or undefined for an id that holds none. */
    state?: (id: string) => StateHook | undefined;
}
export declare function builtin(name: string): CwBuiltin;
export declare function jsx(type: unknown, props: Record<string, unknown> | null): Node;
export declare const jsxs: typeof jsx;
export declare const jsxDEV: typeof jsx;
/**
 * Draw `make()` into `host`, replacing what it held. Returns the cleanup that
 * calls every component's own.
 */
export declare function render(host: HTMLElement, api: ComponentHostApi, make: () => unknown): () => void;

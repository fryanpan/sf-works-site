/**
 * The map's GeoJSON layers on a Leaflet map (`layers.ts` reads them; this
 * draws them), under the map's points and markers.
 *
 * Line, polygon and circle layers share the canvas the points draw on, in the order
 * the props declare them and beneath every point. One canvas, because a
 * Leaflet canvas answers taps for its own paths only: a second canvas above
 * it would swallow every tap meant for a path below. After any change the
 * paths are restacked (`restack`), so a layer switched back on goes back to
 * its place rather than on top.
 *
 * A heatmap is a canvas of its own that takes no taps (`heat.ts`). One
 * declared before every line, polygon and circle layer draws beneath them; one
 * declared after any draws above them and the points, still under the
 * markers.
 *
 * A path layer goes on in chunks of `CHUNK` features, the first at once and
 * one per frame after, so tens of thousands of paths never hold the page
 * for one long task while Leaflet builds them.
 *
 * Popups are built when a path is tapped, from the layer's template, as text.
 */
import L from 'leaflet';
import { type LayerData, type MapLayer } from './layers.js';
/** A layer with its data judged, ready to draw. */
export interface ReadyLayer {
    layer: MapLayer;
    data: LayerData;
}
/** Path features built per frame. */
export declare const CHUNK = 2000;
export declare class LayerStack {
    private readonly map;
    /** The renderer the points draw with. */
    private readonly renderer;
    private drawn;
    /** Bumped by every `set`, so a chunk left over from the last one stops. */
    private generation;
    private readonly group;
    constructor(map: L.Map, 
    /** The renderer the points draw with. */
    renderer: L.Renderer);
    /** Replace every layer with `ready`, in declared order. A layer `hidden`
     *  names is drawn switched off. */
    set(ready: readonly ReadyLayer[], hidden: ReadonlySet<string>): void;
    /** Add the next `CHUNK` features, then come back next frame for more. */
    private build;
    private pathsOf;
    /** Switch one layer on or off; the rest stay as they are. */
    show(id: string, on: boolean): void;
    /** Put the paths back in declared order, beneath the points: each layer,
     *  last to first, goes to the back of the shared canvas. */
    restack(): void;
    /** What every layer covers, switched on or off, or null with nothing. */
    bounds(): L.LatLngBounds | null;
    /** Cells the visible heatmaps stamped on their last redraw. */
    heatCells(): number;
    remove(): void;
}

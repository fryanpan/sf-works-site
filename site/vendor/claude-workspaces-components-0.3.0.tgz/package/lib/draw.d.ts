/**
 * The Leaflet drawing of a map: one renderer for the board's `<StreetMap>`
 * and for the package's map component (`map.ts`), so a board doc and a site
 * draw the same map from the same spec.
 *
 * It draws a spec `core/map-spec.ts` has already judged, on the basemap
 * `core/map-basemaps.ts` names. Markers and rings are SVG paths, so each is
 * an element a test can count and a reader can tap; the points, which run to
 * thousands, share one canvas. Popups are built when opened, as text nodes.
 * A basemap drawn by its provider's own script (Google's) goes under the same
 * layers through `google.ts`.
 *
 * The board builds this file into `/app/map/map.js` through
 * `workspaces-app/src/map-entry.ts`, fetched the first time a doc shows a
 * `<StreetMap>`, so a page with no map pays nothing for it.
 */
import type { Basemap } from './core/map-basemaps.js';
import type { MapSpec } from './core/map-spec.js';
import { type ReadyLayer } from './draw-layers.js';
/** What the slot carries once drawn: how many of each layer went on. */
export interface MapDrawn {
    markers: number;
    rings: number;
    points: number;
}
/** For a basemap its provider's script draws: the key the host handed the
 *  map, the basemap to draw instead if the provider cannot, and who to tell. */
export interface KeyedBase {
    key: string;
    fallback: Basemap;
    fellBack: (why: 'refused' | 'unloaded') => void;
}
/** A map on a slot, whose layers can be drawn again from a new spec. */
export interface LiveMap {
    /** Replace every layer with `spec`'s; with `refit`, move the view to it. */
    draw(spec: MapSpec, refit: boolean): MapDrawn;
    /** Replace the GeoJSON layers (`draw-layers.ts`), the ones `hidden` names
     *  switched off; with `refit`, frame the last spec drawn and them. */
    setLayers(ready: readonly ReadyLayer[], hidden: ReadonlySet<string>, refit: boolean): void;
    /** Switch one GeoJSON layer on or off. */
    showLayer(id: string, on: boolean): void;
    /** Cells the visible heatmaps stamped on their last redraw. */
    heatCells(): number;
    remove(): void;
}
/** Start a map with its basemap on `slot`. It removes itself once the slot
 *  leaves the page. */
export declare function createLiveMap(slot: HTMLElement, base: Basemap, keyed?: KeyedBase): LiveMap;
/** Draw `spec` into `slot`; returns the cleanup that removes the map. */
export declare function renderMapInto(slot: HTMLElement, spec: MapSpec, base: Basemap, keyed?: KeyedBase): {
    drawn: MapDrawn;
    remove: () => void;
};

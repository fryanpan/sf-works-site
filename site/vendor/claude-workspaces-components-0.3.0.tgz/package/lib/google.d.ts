/**
 * Google's roadmap under a map on the `google` basemap, built beside Leaflet
 * (`draw.ts`). Nothing asks Google for anything until a map on that basemap
 * is drawn with a key.
 *
 * The map is drawn by Google's Maps JavaScript API, loaded once per page with
 * the browser key the host passed: on a board doc, the one the server handed
 * the doc (`routes/doc-map-key.ts`); on a site, the page's own `basemapKey`.
 * GoogleMutant moves the tiles the API draws into a Leaflet layer, so the
 * markers, rings, points, popups and legend are the same Leaflet code every
 * other basemap uses, and Google's logo and terms link are moved into the
 * map's corners. GoogleMutant 0.15 is the last release for Leaflet 1; it
 * reads a global `L`, which `leaflet-global.ts` sets before it loads.
 *
 * A key Google refuses (`gm_authFailure`) or a script that does not load
 * swaps the map onto its fallback basemap, and the caller says so under it.
 */
import './leaflet-global.ts';
import 'leaflet.gridlayer.googlemutant/src/Leaflet.GoogleMutant.mjs';
import L from 'leaflet';
/**
 * Put Google's roadmap under `map` once the API has loaded. `fallBack` runs at
 * most once, with the reason, if Google cannot draw it; the caller then draws
 * the fallback basemap.
 */
export declare function addGoogleLayer(map: L.Map, script: string, key: string, maxZoom: number, fallBack: (why: 'refused' | 'unloaded') => void): void;
/** Forget the page's loaded API, so a test starts from a page without it. */
export declare function resetGoogleForTest(): void;

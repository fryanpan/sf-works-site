/**
 * A heatmap as a Leaflet layer: one canvas the size of the map, redrawn
 * when the view settles. Each point stamps a soft disc of its weight into
 * the canvas's alpha, and the alpha is then coloured along the layer's ramp
 * (the method of simpleheat, which leaflet.heat draws with, written here so
 * the package takes no plugin that patches the global `L`).
 *
 * Points are first binned into cells half a radius wide, so a redraw stamps
 * at most one disc per cell: tens of thousands of points cost a pass over
 * the array and a few thousand stamps, not one stamp each. The canvas takes
 * no pointer events, so a tap goes through to the paths beneath.
 */
import L from 'leaflet';
import type { HeatPoint, HeatmapLayer } from './layers.js';
export declare class HeatLayer extends L.Layer {
    private readonly spec;
    private readonly points;
    private readonly paneName;
    private canvas;
    private brush;
    private ramp;
    /** Cells stamped on the last redraw: what a test reads off the slot. */
    stamped: number;
    constructor(spec: HeatmapLayer, points: readonly HeatPoint[], paneName: string);
    onAdd(map: L.Map): this;
    onRemove(map: L.Map): this;
    /** Draw the points the view holds, binned into cells. */
    redraw(): void;
}

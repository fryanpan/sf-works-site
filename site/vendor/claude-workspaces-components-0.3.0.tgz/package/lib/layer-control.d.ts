import type { ReadyLayer } from './draw-layers.js';
/**
 * The map's GeoJSON layers between their props and the renderer: it fetches
 * a `url` layer's file once per map, judges each layer's data in declared
 * order against the map's caps, and draws the list under the map that
 * switches each layer on and off.
 *
 * A layer whose file is still coming says "loading" in its row; one whose
 * file fails, or whose data breaks a rule, says why there and draws nothing,
 * and every other layer still draws. Each row carries its state
 * (`data-state`: drawn, off, loading, failed) and its feature count
 * (`data-features`), which is what a test reads.
 */
import { type MapLayer } from './layers.js';
/** What the map draws now: the layers ready, which are off, and a key that
 *  changes when what they frame changes. */
export interface LayersNow {
    ready: ReadyLayer[];
    hidden: ReadonlySet<string>;
    frame: string;
}
export declare class LayerControl {
    private readonly list;
    /** Called when the ready layers change. */
    private readonly changed;
    /** Called when the reader switches a layer. */
    private readonly toggled;
    private readonly fetchJson;
    private layers;
    private readonly fetched;
    private readonly hidden;
    /** Ids seen before, so a layer's `visible` applies once, not on every
     *  redraw over a reader's own choice. */
    private readonly seen;
    private now;
    private gone;
    constructor(list: HTMLElement, 
    /** Called when the ready layers change. */
    changed: (now: LayersNow) => void, 
    /** Called when the reader switches a layer. */
    toggled: (id: string, on: boolean) => void, fetchJson?: (url: string) => Promise<unknown>);
    /** Take a new set of layers (a redraw of the props or the state). */
    update(layers: MapLayer[], showList: boolean): void;
    /** Switch a layer from the host page, as its row's switch would. An id
     *  not yet drawn is remembered, so it starts that way when it arrives. */
    setVisible(id: string, on: boolean): void;
    current(): LayersNow;
    remove(): void;
    private load;
    private settle;
    /** Judge every layer whose data is here, in order, and redraw the list. */
    private pass;
    private rowOf;
}

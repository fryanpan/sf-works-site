/**
 * Leaflet 1.9.4's stylesheet, compacted. Written by
 * `scripts/leaflet-css.ts`; do not edit by hand.
 */
export declare const LEAFLET_CSS: string;

/**
 * The street map as a component: one file that draws the same map a board
 * doc's `<StreetMap>` draws, and runs unchanged in a doc and on a site
 * (components design, "One component, three hosts").
 *
 *   mount(el, { markers: [...], rings: [150, 300] }, state?)
 *
 * Its props are the `<StreetMap>` props `core/map-spec.ts` reads (`markers`,
 * `points`, `rings`, `categories`, `center`, `zoom`, `height`, `legend`,
 * `basemap`), plus a `title`, `subtitle` and `note`, plus `basemapKey`.
 * Every key of `MAP_STATE_KEYS` the state holds replaces the prop of that
 * name, so an agent or a reader can move pins or change what is shown without
 * touching the tag, and the map redraws whenever the state changes. The view
 * moves only when what it frames changed, so a title edit leaves a reader's
 * pan alone.
 *
 * `layers` adds GeoJSON line, polygon, circle and heatmap layers beneath the
 * points and markers, each switched on and off from a list under the map or
 * by the host through the handle's `setVisible` (`layers.ts` reads them,
 * `layer-control.ts` loads them, `draw-layers.ts` draws them). A map of
 * layers alone needs no markers or points.
 *
 * The basemap is a prop. With none named it is OpenStreetMap, which needs no
 * key, or Google's roadmap when the host passes `basemapKey`. A host that
 * names a keyed basemap and passes no key gets its fallback and a line
 * saying so. In a doc the state hook is live over the doc's Y.Doc; on a site
 * it is a hook over a JSON snapshot (`mountWithSnapshot`), whose writes stay
 * on the page. With no hook it draws its props.
 *
 * Text reaches the page only as text nodes.
 */
import { type SnapshotOptions } from './core/component-snapshot.js';
import { type Basemap } from './core/map-basemaps.js';
import type { StateHook } from './core/mdx-component-runtime.js';
/** The state keys that replace the prop of the same name. */
export declare const MAP_STATE_KEYS: readonly ["markers", "points", "rings", "categories", "center", "zoom", "title", "subtitle", "note", "layers"];
/** A marker or a point. `latitude`, `lon` and `longitude` are read too. */
export type MapRow = {
    lat: number;
    lng: number;
    label?: string;
    popup?: string;
    category?: string;
};
/** A ring around every marker: feet as a number, or an object. */
export type MapRingProp = number | {
    feet: number;
    color?: string;
    label?: string;
} | {
    meters: number;
    color?: string;
    label?: string;
};
/** A GeoJSON layer: `data` inline or a `url` to fetch, and how to draw it.
 *  `layers.ts` holds the defaults and ranges each field is read with. */
export type MapLayerProp = {
    /** Unique on the map; `layer-<index>` without. */
    id?: string;
    /** The words beside its switch. */
    name?: string;
    /** A FeatureCollection, a Feature, a list of Features or a geometry. */
    data?: unknown;
    /** A GeoJSON file, relative to the page or http(s). */
    url?: string;
    /** `false` starts it switched off. */
    visible?: boolean;
    /** `{key}` is filled from each feature's properties, as text. */
    popup?: string;
} & ({
    type: 'line';
    color?: string;
    width?: number;
    opacity?: number;
    dash?: number[] | string;
} | {
    type: 'polygon';
    fill?: string;
    fillOpacity?: number;
    outline?: string;
    outlineWidth?: number;
    outlineOpacity?: number;
} | {
    type: 'heatmap';
    /** The property each point's weight is read from. */
    weight?: string;
    radius?: number;
    intensity?: number;
    /** 2 to 8 colours, cold to hot. */
    colors?: string[];
    opacity?: number;
} | {
    type: 'circle';
    fill?: string;
    fillOpacity?: number;
    stroke?: string;
    /** Pixels, 0 to 20; 0 draws no stroke. */
    strokeWidth?: number;
    strokeOpacity?: number;
    /** Pixels, 1 to 40, the same at every zoom. */
    radius?: number;
});
/** What `mount` returns: call it to remove the map. */
export type MapHandle = (() => void) & {
    /** Switch the layer with this id on or off, as its row's switch would;
     *  the row shows the change. An id the map does not draw changes nothing
     *  now and holds if a layer with that id arrives later. */
    setVisible(id: string, on: boolean): void;
};
/** What a host passes the map. Every field is optional except that a map
 *  needs `markers` or `points`, here or in its state. */
export type MapProps = {
    /** The state's id: in a doc, the tag's `id`. */
    id?: string;
    markers?: MapRow[];
    points?: MapRow[];
    rings?: MapRingProp[];
    /** GeoJSON layers beneath the points and markers, in drawing order. */
    layers?: MapLayerProp[];
    /** `{ name: "#hex" }` or `[{ name, color }]`: the legend's order and colours. */
    categories?: Record<string, string> | Array<{
        name: string;
        color?: string;
    }>;
    center?: [number, number];
    zoom?: number;
    /** Pixels, 160 to 1200; 480 by default. */
    height?: number;
    legend?: boolean;
    /** `osm`, `carto-light` or `google`. */
    basemap?: string;
    /** The key for a basemap that needs one (Google's browser key). */
    basemapKey?: string;
    title?: string;
    subtitle?: string;
    note?: string;
};
/** The basemap a map draws on, from its props alone. */
export type BasemapChoice = {
    name: string;
    base: Basemap;
    keyed?: {
        key: string;
        fallback: string;
    };
    notice?: string;
} | {
    error: string;
};
/** Which basemap `props` draw on: the one named, else Google with a key and
 *  OpenStreetMap without. A keyed basemap with no key draws its fallback. */
export declare function chooseBasemap(props: Record<string, unknown>): BasemapChoice;
/** The props with each state key the state holds in place of its prop. */
export declare function withState(props: Record<string, unknown>, state: unknown): Record<string, unknown>;
export default function mount(el: HTMLElement, props: Record<string, unknown>, state?: StateHook): MapHandle;
/**
 * Mount the map on a page that is not a doc, with a state hook over
 * `snapshot`: the JSON `get_component_state` returned for the doc's map.
 * Writes change this page's copy only. Returns the map's handle: the
 * cleanup, with `setVisible`.
 */
export declare function mountWithSnapshot(el: HTMLElement, props: MapProps, snapshot?: unknown, opts?: SnapshotOptions): MapHandle;

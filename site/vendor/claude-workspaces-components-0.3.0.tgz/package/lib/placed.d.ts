/**
 * Call `fn` once the slot is in the document and laid out. Leaflet measures
 * its container when it starts, so a map started before then has no size:
 * a doc's node view is built before ProseMirror puts it in the page, and a
 * doc component's element before the page places it. A page that never lays
 * out (a test's DOM) draws once the slot is connected.
 */
export declare function whenPlaced(slot: HTMLElement, fn: () => void): void;

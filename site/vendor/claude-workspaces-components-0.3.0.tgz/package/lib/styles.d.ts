/** Put the styles in the document or shadow root `el` sits in, once. */
export declare function ensureStyles(el: HTMLElement): void;

/**
 * What a street map's popup may hold: words, or a small card. Read here for
 * markers and points (`map-spec.ts`) and for GeoJSON layers
 * (`components/src/layers.ts`), drawn by `components/src/popup-node.ts`.
 *
 * A card is a title, lines and one link. It is data, never markup: every
 * field reaches the page as a text node, so it can carry no script and no
 * event handler, and its link is kept only when it is an http(s) URL. A
 * layer's card fields are templates filled from the tapped feature, so the
 * link is checked again once filled.
 */
/** A popup's card. */
export interface MapCard {
    title?: string;
    /** At most `CARD_LINES` lines, each one paragraph of text. */
    lines?: string[];
    /** Opens in a new tab. `text` defaults to the href. */
    link?: {
        href: string;
        text?: string;
    };
}
/** Words, or a card. */
export type MapPopup = string | MapCard;
export declare const CARD_LINES = 20;
/** True for an http(s) URL, the only links a card keeps. */
export declare function isWebHref(href: string): boolean;
export type PopupRead = {
    ok: true;
    value: MapPopup | undefined;
} | {
    ok: false;
    error: string;
};
/** Read a `popup` prop: text, a number, a card, or nothing. `at` names it in
 *  the error, e.g. `markers[3].popup`. A card with no field is nothing.
 *
 *  `templated` is a layer's card, whose fields are `{key}` templates: its
 *  link may also start with a whole key (`{url}`), since only the filled
 *  value can be judged, and `popup-node.ts` judges it once filled. */
export declare function readPopup(v: unknown, at: string, templated?: boolean): PopupRead;
/** Fill `{key}` in `template` from `props`, as text. A key the feature
 *  lacks, or whose value is not a string, number or boolean, fills empty. */
export declare function popupText(template: string, props: Record<string, unknown>): string;

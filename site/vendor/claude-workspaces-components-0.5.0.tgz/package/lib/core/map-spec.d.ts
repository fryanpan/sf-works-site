import { type MapPopup } from './map-card.js';
/** Observable 10, the scheme PlotChart's categories draw in. */
export declare const CATEGORY_COLORS: readonly string[];
export declare const FEET_TO_METERS = 0.3048;
/** The most a map draws, so one doc cannot stall every reader's page. */
export declare const MAP_LIMITS: {
    readonly markers: 2000;
    readonly points: 50000;
    readonly rings: 6;
};
export interface MapMarker {
    lat: number;
    lng: number;
    label?: string;
    popup?: MapPopup;
    /** Shown on hover, as text. */
    tooltip?: string;
    color: string;
}
export interface MapPoint {
    lat: number;
    lng: number;
    popup?: MapPopup;
    tooltip?: string;
    color: string;
}
export interface MapRing {
    meters: number;
    label: string;
    color: string;
}
export interface MapCategory {
    name: string;
    color: string;
}
export interface MapSpec {
    markers: MapMarker[];
    points: MapPoint[];
    rings: MapRing[];
    categories: MapCategory[];
    center?: [number, number];
    zoom?: number;
    height: number;
    legend: boolean;
    basemap: string;
    /** Whether the tag named its basemap, rather than taking the default. A
     *  default map that cannot have Google's key draws on the fallback without
     *  a notice, because nobody asked for Google. */
    basemapNamed: boolean;
    /** A plain wheel over the map scrolls the page and shows a hint; Ctrl or
     *  Cmd with the wheel zooms. Off, the wheel never zooms. */
    cooperativeGestures: boolean;
}
export type MapRead = {
    ok: true;
    spec: MapSpec;
} | {
    ok: false;
    error: string;
};
/** The tag's own props, with each data prop it left out taken from the file. */
export declare function mergeMapData(props: Record<string, unknown>, file: unknown): Record<string, unknown>;
/** Read `props` (the tag's, merged with its file's) into what the map draws. */
export declare function readMapSpec(props: Record<string, unknown>): MapRead;
/** A `src` relative to the doc, as path segments, or null for one that is
 *  absolute, climbs out, or is not a `.json` file. */
export declare function mapDataSegments(src: string): string[] | null;
/**
 * The data files a doc's `<StreetMap>` tags name in a literal `src`, in doc
 * order, given the text of its `mdx-flow` blocks. The server serves these
 * files and no others beside the doc for a map (`doc-file-scope.ts`).
 */
export declare function mapDataPaths(blocks: readonly string[]): string[][];
/**
 * The basemaps a doc's `<StreetMap>` tags draw on, once each, given the text
 * of its `mdx-flow` blocks: the one a literal `basemap` names, and
 * `DEFAULT_BASEMAP` for a tag with no `basemap` at all. The server hands a
 * basemap's key only to a doc this names it for (`routes/doc-map-key.ts`).
 */
export declare function mapBasemapNames(blocks: readonly string[]): string[];

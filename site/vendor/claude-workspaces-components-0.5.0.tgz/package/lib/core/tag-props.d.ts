/**
 * The props of a JSX opening tag in an `.mdx` doc, read as literals by one
 * parser that both sides use: the page, to draw a component's preview
 * (`workspaces-app/src/mdx-preview.ts`), and the server, to decide which data
 * file a `<StreetMap src>` lets a visitor read (`map-spec.ts`, called from
 * `server/src/doc-file-scope.ts`). One reader, so a tag the page draws from a
 * file is a tag the server serves that file for, and no other.
 *
 * The source is somebody's document text, so nothing here runs it. Values are
 * numbers, strings, booleans, null, arrays and plain objects; anything else (a
 * variable, a call, a spread) is `UNREADABLE`. A bare attribute is `true`.
 */
/** A prop whose value is not a literal: a variable, a call, a spread. */
export declare const UNREADABLE: unique symbol;
export interface OpenTag {
    /** The tag's name (`StreetMap`, `Foo.Bar`), or '' for a fragment `<>`. */
    name: string;
    /** Literal props by name; a prop the reader could not read is `UNREADABLE`.
     *  Empty when the tag is not closed. */
    props: Map<string, unknown>;
    /** Index in the source just past the tag's `>` or `/>`, or -1 when a
     *  quote, a brace or the `>` is missing. */
    end: number;
}
/** The opening tag that starts at `s[at]` (a `<`). */
export declare function readOpenTag(s: string, at?: number): OpenTag;

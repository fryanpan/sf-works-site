/**
 * The map's GeoJSON layers on a Leaflet map (`layers.ts` reads them; this
 * draws them), under the map's points and markers.
 *
 * Line, polygon and circle layers share the canvas the points draw on, in the order
 * the props declare them and beneath every point. One canvas, because a
 * Leaflet canvas answers taps for its own paths only: a second canvas above
 * it would swallow every tap meant for a path below. After any change the
 * paths are restacked (`restack`), so a layer switched back on goes back to
 * its place rather than on top.
 *
 * A heatmap is a canvas of its own that takes no taps (`heat.ts`). One
 * declared before every line, polygon and circle layer draws beneath them; one
 * declared after any draws above them and the points, still under the
 * markers.
 *
 * A path layer goes on in chunks of `CHUNK` features, the first at once and
 * one per frame after, so tens of thousands of paths never hold the page
 * for one long task while Leaflet builds them.
 *
 * A layer with `minZoom` or `maxZoom` is on the map only while the zoom is
 * inside that range, both ends included. The stack follows the map's own
 * zoom, because the page's handle hears of no zoom change; the reader's
 * switch is kept apart from it, so a layer switched on outside its range
 * draws once the zoom enters it.
 *
 * Popups and hover tooltips are built when they open, from the layer's
 * templates, as text (`popup-node.ts`). A layer with a popup, a tooltip or
 * `clickable` takes taps, and each tap is handed to `onHit` with the
 * feature's index and properties.
 */
import L from 'leaflet';
import { type LayerData, type MapLayer } from './layers.js';
/** A tap on a feature of layer `id`: its index in the layer's data. */
export type LayerHit = (id: string, index: number, at: L.LatLng, properties: Record<string, unknown>) => void;
/** A layer with its data judged, ready to draw. */
export interface ReadyLayer {
    layer: MapLayer;
    data: LayerData;
}
/** Path features built per frame. */
export declare const CHUNK = 2000;
export declare class LayerStack {
    private readonly map;
    /** The renderer the points draw with. */
    private readonly renderer;
    private readonly onHit;
    private drawn;
    /** Bumped by every `set`, so a chunk left over from the last one stops. */
    private generation;
    private readonly group;
    private readonly rezoom;
    constructor(map: L.Map, 
    /** The renderer the points draw with. */
    renderer: L.Renderer, onHit?: LayerHit);
    /** Replace every layer with `ready`, in declared order. A layer `hidden`
     *  names is drawn switched off. */
    set(ready: readonly ReadyLayer[], hidden: ReadonlySet<string>): void;
    /** Add the next `CHUNK` features, then come back next frame for more. */
    private build;
    private pathsOf;
    /** Switch one layer on or off; the rest stay as they are. */
    show(id: string, on: boolean): void;
    /** Put a layer on the map or take it off, as its switch and the zoom say. */
    private attach;
    /** Put the paths back in declared order, beneath the points: each layer,
     *  last to first, goes to the back of the shared canvas. */
    restack(): void;
    /** What every layer covers, switched on or off, or null with nothing. */
    bounds(): L.LatLngBounds | null;
    /** Cells the visible heatmaps stamped on their last redraw. */
    heatCells(): number;
    remove(): void;
}

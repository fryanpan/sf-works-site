/**
 * The map's `layers` prop, read and judged before anything draws: GeoJSON
 * line, polygon, circle and heatmap layers over the basemap, under the map's
 * own points and markers.
 *
 *   layers: [
 *     { type: 'polygon', name: 'Saltmarsh quarter', data, fill: '#a463f2' },
 *     { type: 'line', name: 'Riverbend paths', url: './paths.geojson',
 *       color: '#ff725c', width: 3, popup: '{name}: {speed} mph' },
 *     { type: 'circle', name: 'Riverbend reports', data, fill: '#e11d48',
 *       radius: 5, popup: '{kind}' },
 *     { type: 'heatmap', name: 'Harborlight reports', data, weight: 'count' },
 *   ]
 *
 * A layer's data is inline (`data`: a FeatureCollection, a Feature, a list
 * of Features or a bare geometry) or a GeoJSON file the page fetches (`url`,
 * relative to the page or http(s)). `readLayers` judges the props alone and
 * leaves a `url` layer waiting; `readLayerData` judges the data once it is
 * here, so a file that fails names its own layer and the rest still draw.
 *
 * Nothing here touches Leaflet or the DOM. A popup (text or a card,
 * `core/map-card.ts`) and a tooltip are templates whose `{key}` names a
 * feature property, filled as text (`popupText`).
 */
import { type MapPopup } from './core/map-card.js';
export { popupText } from './core/map-card.js';
export type LayerType = 'line' | 'polygon' | 'circle' | 'heatmap';
/** The most a map's layers hold, so one page cannot stall a reader's. Lines
 *  and polygons are canvas paths Leaflet reprojects on every zoom, so their
 *  cap counts vertices; a circle is one canvas path per position, so its cap
 *  counts positions; heatmap points are binned into cells per redraw. */
export declare const LAYER_LIMITS: {
    readonly layers: 24;
    /** Line and polygon features across every layer of a map. */
    readonly features: 50000;
    /** Line and polygon vertices across every layer of a map. */
    readonly vertices: 1000000;
    /** Heatmap points across every layer of a map. */
    readonly heatPoints: 200000;
    /** Circle positions across every layer of a map: each is a path of its
     *  own, held to the same order as the map's 50,000 `points`. */
    readonly circles: 20000;
};
/** Heatmap colours, cold to hot, when a layer names none. */
export declare const HEAT_COLORS: readonly string[];
/** What a line, polygon or circle layer does under a reader's pointer. */
interface Tappable {
    popup?: MapPopup;
    /** Shown on hover. */
    tooltip?: string;
    /** Takes taps, for the map's click event, with no popup or tooltip. */
    clickable?: boolean;
}
/** What a layer looks like once read; its features arrive with `data`. */
interface LayerBase {
    /** The layer's id: the one given, else `layer-<index>`. */
    id: string;
    name: string;
    visible: boolean;
    /** The zooms it draws at, both ends included; an end not given is open. */
    minZoom?: number;
    maxZoom?: number;
    /** Inline data, or a URL still to fetch. */
    source: {
        data: unknown;
    } | {
        url: string;
    };
}
export interface LineLayer extends LayerBase, Tappable {
    type: 'line';
    color: string;
    width: number;
    opacity: number;
    /** Leaflet's `dashArray`, e.g. `"6 4"`. */
    dash?: string;
}
export interface PolygonLayer extends LayerBase, Tappable {
    type: 'polygon';
    fill: string;
    fillOpacity: number;
    outline: string;
    outlineWidth: number;
    outlineOpacity: number;
}
export interface CircleLayer extends LayerBase, Tappable {
    type: 'circle';
    fill: string;
    fillOpacity: number;
    stroke: string;
    /** Pixels; 0 draws no stroke. */
    strokeWidth: number;
    strokeOpacity: number;
    /** Pixels, the same at every zoom. */
    radius: number;
}
export interface HeatmapLayer extends LayerBase {
    type: 'heatmap';
    /** The feature property each point's weight is read from; 1 without. */
    weight?: string;
    /** Pixels. */
    radius: number;
    intensity: number;
    colors: string[];
    opacity: number;
}
export type MapLayer = LineLayer | PolygonLayer | CircleLayer | HeatmapLayer;
/** One GeoJSON feature as the renderer takes it: a geometry of the layer's
 *  kind, and its properties. Coordinates are GeoJSON's `[lng, lat]`. */
export interface LayerFeature {
    type: 'Feature';
    geometry: {
        type: string;
        coordinates: unknown;
    };
    properties: Record<string, unknown>;
}
/** A heatmap point. */
export interface HeatPoint {
    lat: number;
    lng: number;
    weight: number;
}
/** `[west, south, east, north]`, or null for a layer with no positions. */
export type Bbox = [number, number, number, number] | null;
export type LayerData = {
    kind: 'paths';
    features: LayerFeature[];
    vertices: number;
    bbox: Bbox;
} | {
    kind: 'heat';
    points: HeatPoint[];
    bbox: Bbox;
};
type Read<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error: string;
};
/** Whether `url` is one a layer may fetch: relative to the page, or http(s). */
export declare function layerUrlAllowed(url: string): boolean;
/** Read every layer's props. Data is judged later, by `readLayerData`. */
export declare function readLayers(v: unknown): Read<MapLayer[]>;
/** What a map's layers have already spent of the caps, across layers. */
export interface LayerBudget {
    features: number;
    vertices: number;
    heatPoints: number;
    circles: number;
}
export declare const emptyBudget: () => LayerBudget;
/**
 * Judge a layer's GeoJSON: every feature's geometry must be of the layer's
 * kind (a null geometry is skipped), every position a finite `[lng, lat]`,
 * and the map's caps unspent. `budget` is what earlier layers used, and is
 * added to on success.
 */
export declare function readLayerData(layer: MapLayer, data: unknown, budget: LayerBudget): Read<LayerData>;

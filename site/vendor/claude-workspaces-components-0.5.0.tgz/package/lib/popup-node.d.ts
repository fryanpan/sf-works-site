/**
 * The DOM of a popup and a tooltip (`core/map-card.ts` says what a popup may
 * hold). Every word is a text node, so nothing in a popup or a tooltip can
 * run, and a card's link is kept only when it is an http(s) URL once filled.
 */
import { type MapPopup } from './core/map-card.js';
/** `fill` fills a layer's `{key}` templates; markers' words pass as they are. */
type Fill = (template: string) => string;
export declare function popupNode(doc: Document, popup: MapPopup, fill?: Fill): HTMLElement;
export declare function tooltipNode(doc: Document, words: string): HTMLElement;
export {};
